-- Create the database
CREATE DATABASE IF NOT EXISTS ems;
USE ems;

-- Create the employee table
CREATE TABLE IF NOT EXISTS employee (
    id INT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    role VARCHAR(50),
    baseSalary DOUBLE
);

-- Create the asset table
CREATE TABLE IF NOT EXISTS asset (
    assetId INT PRIMARY KEY,
    assetName VARCHAR(100),
    assignedTo INT,
    FOREIGN KEY (assignedTo) REFERENCES employee(id)
);
