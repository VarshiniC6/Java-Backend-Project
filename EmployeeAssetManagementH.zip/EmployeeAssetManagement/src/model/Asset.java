package model;

public class Asset {
    private int assetId;
    private String assetName;
    private int assignedTo; // employee ID

    public Asset(int assetId, String assetName, int assignedTo) {
        this.assetId = assetId;
        this.assetName = assetName;
        this.assignedTo = assignedTo;
    }

    // Getters and Setters
    // Getters
    public int getassetId() {
        return assetId;
    }

    public String getassetName() {
        return assetName;
    }

    public int getassignedTo() {
        return assignedTo;
    }

    // Setters
    public void setassetId(int assetId) {
        this.assetId = assetId;
    }

    public void setassetName(String assetName) {
        this.assetName = assetName;
    }

    public void setassignedTo(int assignedTo) {
        this.assignedTo = assignedTo;
    }

}
