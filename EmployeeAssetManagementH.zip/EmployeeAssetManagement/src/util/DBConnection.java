package util;

import java.sql.*;

public class DBConnection {
    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // ✅ optional but safe
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        String url = "jdbc:mysql://localhost:3306/ems";
        String user = "root";
        String password = "Root@1729"; // use your MySQL password
        return DriverManager.getConnection(url, user, password);
    }
}
