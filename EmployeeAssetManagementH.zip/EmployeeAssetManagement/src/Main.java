import model.Employee;
import model.Asset;
import service.Employeeservice;
import service.Assetservice;

public class Main {
    public static void main(String[] args) {
        Employeeservice empService = new Employeeservice();
        Assetservice assetService = new Assetservice();

        // 1️⃣ CREATE (Insert new employee and asset)
        Employee emp1 = new Employee(104, "Alice", "Developer", 60000);
        empService.addEmployee(emp1);

        Employee emp2 = new Employee(105, "Bob", "Tester", 50000);
        empService.addEmployee(emp2);

        Asset asset1 = new Asset(201, "Dell Laptop", 104);
        assetService.assignAsset(asset1);

        Asset asset2 = new Asset(202, "HP Monitor", 105);
        assetService.assignAsset(asset2);

        // 2️⃣ READ (Could be SELECT statements — see MySQL Workbench)
        // Not implemented as Java methods since JDBC prints are optional

        // 3️⃣ UPDATE
        emp1.setrole("Senior Developer");
        emp1.setbaseSalary(75000);
        empService.updateEmployee(emp1); // updates employee 101

        asset1.setassetName("Lenovo ThinkPad");
        assetService.updateAsset(asset1); // updates asset 201

        // 4️⃣ DELETE
        // Delete asset before deleting employee due to foreign key constraint
        assetService.deleteAsset(202); // delete asset 202 (HP Monitor)
        empService.deleteEmployeeWithAssets(102); // delete employee 102 and any linked assets

        System.out.println("\n✅ All CRUD operations executed successfully!");
    }
}
