
package service;

import model.Employee;
import util.DBConnection;

import java.sql.*;

public class Employeeservice {
    public void addEmployee(Employee emp) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "INSERT INTO employee VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, emp.getid());
            ps.setString(2, emp.getname());
            ps.setString(3, emp.getrole());
            ps.setDouble(4, emp.getbaseSalary());
            ps.executeUpdate();
            System.out.println("Employee added!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateEmployee(Employee emp) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE employee SET name = ?, role = ?, baseSalary = ? WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, emp.getname());
            ps.setString(2, emp.getrole());
            ps.setDouble(3, emp.getbaseSalary());
            ps.setInt(4, emp.getid());

            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Employee updated!" : "Employee not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteEmployee(int id) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "DELETE FROM employee WHERE id = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Employee deleted!" : "Employee not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void deleteEmployeeWithAssets(int id) {
    try (Connection con = DBConnection.getConnection()) {
        PreparedStatement ps1 = con.prepareStatement("DELETE FROM asset WHERE assignedTo = ?");
        ps1.setInt(1, id);
        ps1.executeUpdate();

        PreparedStatement ps2 = con.prepareStatement("DELETE FROM employee WHERE id = ?");
        ps2.setInt(1, id);
        int rows = ps2.executeUpdate();

        System.out.println(rows > 0 ? "Employee and assigned assets deleted!" : "Employee not found.");
    } catch (Exception e) {
        e.printStackTrace();
    }
}


}