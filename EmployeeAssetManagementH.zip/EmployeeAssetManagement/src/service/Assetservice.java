
package service;

import model.Asset;
import util.DBConnection;

import java.sql.*;

public class Assetservice {
    public void assignAsset(Asset asset) {
        try (Connection con = DBConnection.getConnection()) {
            // Check if asset is already assigned
            String checkQuery = "SELECT * FROM asset WHERE assetId = ?";
            PreparedStatement check = con.prepareStatement(checkQuery);
            check.setInt(1, asset.getassetId());
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                System.out.println("Asset already assigned.");
                return;
            }

            String query = "INSERT INTO asset VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, asset.getassetId());
            ps.setString(2, asset.getassetName());
            ps.setInt(3, asset.getassignedTo());
            ps.executeUpdate();
            System.out.println("Asset assigned!");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateAsset(Asset asset) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE asset SET assetName = ?, assignedTo = ? WHERE assetId = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setString(1, asset.getassetName());
            ps.setInt(2, asset.getassignedTo());
            ps.setInt(3, asset.getassetId());

            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Asset updated!" : "Asset not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteAsset(int assetId) {
        try (Connection con = DBConnection.getConnection()) {
            String query = "DELETE FROM asset WHERE assetId = ?";
            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, assetId);
            int rows = ps.executeUpdate();
            System.out.println(rows > 0 ? "Asset deleted!" : "Asset not found.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
